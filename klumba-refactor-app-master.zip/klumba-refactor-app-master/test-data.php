<?php

return [
    [
        [
            'id' => 1,
            'email' => 'testuser1@test.com',
            'balance' => 120.45
        ],
        10
    ],
    [
        [
            'id' => 2,
            'email' => 'testuser2@test.com',
            'balance' => 9999.45
        ],
        -10000
    ],
    [
        [
            'id' => 3,
            'email' => 'testuser3@test.com',
            'balance' => 0.45
        ],
        120.23
    ]
];